﻿drop table product CASCADE;
drop table employee CASCADE;
drop table branch CASCADE;
drop table manager CASCADE;
drop table salesman CASCADE;
drop table client CASCADE;
drop table payment CASCADE;
drop table rents CASCADE;
drop table buys CASCADE;
drop table forrent CASCADE;
drop table forsale CASCADE;
drop table fee CASCADE;
drop table paysfor CASCADE;
drop table rates CASCADE;

drop type producttype;
drop type pymtmethod;
drop type rentingduration;
drop type PrConditionType;





