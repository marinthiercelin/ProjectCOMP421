DROP VIEW custmrwithamt CASCADE;
DROP VIEW productyear CASCADE;

