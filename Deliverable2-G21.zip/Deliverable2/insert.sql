﻿/*Insertions*/
INSERT INTO Client VALUES (1, 'Tarek Holzl', 420, 'St-Catherine St. West','Montreal QC','Canada', CURRENT_DATE);
INSERT INTO Client VALUES (2, 'Marin Thiercelin', 8, 'Maisonneuve Bd. East','Montreal QC','Canada', CURRENT_DATE);
INSERT INTO Client VALUES (3, 'William Burgess', 789, 'Parc St.','Montreal QC','Canada', CURRENT_DATE);
INSERT INTO Client VALUES (4, 'Clara Kang', 56, 'Rachel St. East','Montreal QC','Canada', CURRENT_DATE);
INSERT INTO Client VALUES (5, 'Luke Skywalker', 7, 'Main Street','Mos Esley','Tatooine', '0900-05-04');

